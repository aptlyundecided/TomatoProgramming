export * from './svg-file-read';
